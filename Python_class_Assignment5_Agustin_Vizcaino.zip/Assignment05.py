# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   Agustin Vizcaino
# Date:  April 20, 2018
# ChangeLog: (Who, When, What)
#   AV, 04/30/18, Added code to complete assignment 5
#
# Resource: https://www.tutorialspoint.com/python/python_dictionary.htm
# -------------------------------------------------#

# -- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

# -- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

# -- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
# -------------------------------

objFileName = "C:\_PythonClass\Todo.txt"
strData = ""
dicRow = {}
lstTable = []

# Step 1 - Load data from a file
# When the program starts, load each "row" of data
# in "ToDo.txt" into a python Dictionary.
# Add the each dictionary "row" to a python list "table"

with open(objFileName, 'r') as file:                        #loads data from file
    for text in file:                                       #For loop used to load each row of data
        text = text.strip().split(',')                      #defines the text and the comma delimiter
        dicRow = {'Task': text[0], 'Priority': text[1]}     #tells the program how to populate each row
        lstTable.append(dicRow)                             #appends each new row to the end of the list table


# Step 2 - Display a menu of choices to the user
while (True):
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()  # adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        print('You have selected to view your TO DO LIST')      #statement to let user know they have selected to view list
        for item in lstTable:                                   #loops each item in table
            print(item)                                         #shows/prints each item in table
        print(len(lstTable),' items in Table')                  #additional statement to show how many items in table
        continue

    # Step 4 - Add a new item to the list/Table
    elif (strChoice.strip() == '2'):
        print('You have selected to add a new Task to your TO DO LIST')
        strTask = input('Task: ')                                #outlines 1st item in dictionrary
        strPriority = input('Priority: ')                        #outlines 2nd item in dictionary
        dicRow = {'Task': strTask, 'Priority': strPriority.lower()}     #sets up dictionary row
        lstTable.append(dicRow)                                 #Appends row to end of Table
        print('Added Task: ',strTask,' (',strPriority,' Priority ) to your TO DO LIST') #explains row was added
        continue

    # Step 5 - Remove an item in the list/Table
    elif (strChoice == '3'):
        print('You have selected to remove a new item')
        strTask = input('Which Task do you wish to remove? ')   #asks user for Task to be removed
        strPriority = input('Which Priority? ')                 #asks user to confirm level of priority of task
        dicRow = {'Task': strTask, 'Priority': strPriority.lower()} #sets up dictionary row to be removed
        try:                                                        #tries the following code if no error
            print(dicRow,' will be removed from your TO DO LIST')   #statement to tell user which row will be removed
            lstTable.remove(dicRow)                                 #command to remove selected row from Table
        except:                                                 #if Task not found, runs the following code
            print('Could not find *',strTask,'* with Priority ',strPriority.capitalize(),' in your TO DO LIST')
                                                               #statement to show what error ocurred

    # Step 6 - Save tasks to the ToDo.txt file
    elif (strChoice == '4'):
        saveFile = open(objFileName, "w+")          # Overwrite to File
        for lines in lstTable:                      # loops for all rows in table
            saveFile.write(str(lines['Task'])+','+str(lines['Priority'])+'\n')  #writes lines to text file
        saveFile.close()                            #closes file
        print('Saved your TO DO LIST')              #statement lets user know table was saved to file
        continue
    elif (strChoice == '5'):
        break                                      # and Exit the program

